import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
  },
  paper: {
    padding: theme.spacing(1),
    textAlign: 'center',
    color: theme.palette.text.secondary,
  },
}));

var bg1 = {
  border: "1px solid rgb(119, 72, 72)",
  color:"#000",
  background: "#ccc"
};
var bg2 = {
  background: "orange",
  border: "1px rgb(134, 50, 50) solid",
};
var bg3 = {
  background: "green",
  border: "1px #ccc solid",
  color:"#fff"
};

export default function NestedGrid() {
  const classes = useStyles();

  function FormRow() {
    return (
      <React.Fragment>
        <Grid item xs={4}>
        <Paper className={classes.paper} >
        <Grid container spacing={2}>
           <Grid item xs={12} sm container style={bg1}>
            <Grid item xs container direction="column" spacing={2} >
              <Grid item xs >
                <Typography gutterBottom variant="subtitle1">
                Welcome to CodeSandbox
                </Typography>
                <Typography variant="body2" gutterBottom>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
quis nostrud exercitation ullamco laboris
                </Typography>
               
              </Grid>
              
            </Grid>
           
          </Grid>
        </Grid>
      </Paper>
     
        </Grid>
        <Grid item xs={4}>
        <Paper className={classes.paper} >
        <Grid container spacing={2}>
           <Grid item xs={12} sm container style={bg2}>
            <Grid item xs container direction="column" spacing={2}>
              <Grid item xs>
                <Typography gutterBottom variant="subtitle1">
                Welcome to CodeSandbox
                </Typography>
                <Typography variant="body2" gutterBottom>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
quis nostrud exercitation ullamco laboris
                </Typography>
               
              </Grid>
              
            </Grid>
           
          </Grid>
        </Grid>
      </Paper>
     
        </Grid>
        <Grid item xs={4}>
        <Paper className={classes.paper} >
        <Grid container spacing={2}>
           <Grid item xs={12} sm container style={bg3}>
            <Grid item xs container direction="column" spacing={2}>
              <Grid item xs>
                <Typography gutterBottom variant="subtitle1">
                Welcome to CodeSandbox
                </Typography>
                <Typography variant="body2" gutterBottom>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
quis nostrud exercitation ullamco laboris
                </Typography>
               
              </Grid>
              
            </Grid>
           
          </Grid>
        </Grid>
      </Paper>
     
        </Grid>
      </React.Fragment>
    );
  }

  return (
    <div className={classes.root}>
      <Grid container spacing={1}>
        <Grid container item xs={12} spacing={3}>
          <FormRow />
        </Grid>
       
      </Grid>
    </div>
  );
}
